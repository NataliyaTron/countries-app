import React from "react";
import { AppRouter } from "./AppRouter";
import "./normalize.scss";

const App = () => {
    return <AppRouter />;
};

export default App;
